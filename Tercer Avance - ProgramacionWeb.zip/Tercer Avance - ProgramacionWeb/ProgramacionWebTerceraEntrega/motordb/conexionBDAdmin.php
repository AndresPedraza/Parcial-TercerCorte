<?php

//Definir valores constantes
define('HOST', 'localhost');
define('USER', 'root');
define('PASSWORD', '');
define('DATABASE', 'iniciodesesiondb');

?>