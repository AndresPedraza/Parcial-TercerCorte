<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>Panel de Administración - Noticias</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="container-fluid py-5">
        <h1 class="text-center">Administración de Noticias</h1>
        
        <div class="row mt-5">
            <div class="col-lg-12">
                <h3>Agregar Nueva Noticia</h3>
                <form action="controller/controlador-noticias.php" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="descripcion">Descripción:</label>
                        <textarea class="form-control" id="descripcion" name="descripcion" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="imagen">Imagen:</label>
                        <input type="file" class="form-control" id="imagen" name="imagen" required>
                    </div>
                    <button type="submit" name="agregar" class="btn btn-primary">Agregar Noticia</button> <br><br>
                    <p><a href="admin.php"  class="btn btn-primary">Regresar  </a></p>

                </form>
            </div>
        </div>

        <h2 class="mt-5">Noticias Publicadas</h2>
        <div class="row">

        <?php

        $conexion = new mysqli('localhost', 'root', '', 'iniciodesesiondb');
            if ($conexion->connect_error) {
                die("Conexión fallida: " . $conexion->connect_error);
            }


            $resultado = $conexion->query("SELECT * FROM noticias ORDER BY id DESC");


            while ($row = $resultado->fetch_assoc()) {
                echo '
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card">
                            <img class="card-img-top" src="' . $row['imagen'] . '" alt="Imagen noticia">
                            <div class="card-body">
                                <!-- Editable description field -->
                                <form action="controller/controlador-noticias.php" method="POST">
                                    <textarea class="form-control" name="descripcion" rows="4">' . $row['descripcion'] . '</textarea>
                                    <input type="hidden" name="id" value="' . $row['id'] . '">
                                    <button type="submit" name="modificar" class="btn btn-warning mt-3">Modificar</button>
                                </form>
                                <a href="controller/controlador-noticias.php?eliminar=' . $row['id'] . '" class="btn btn-danger mt-3">Eliminar</a>
                            </div>
                        </div>
                    </div>';
            }
            ?>
        </div>
    </div>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>
