<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-eqiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" 
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="frame/style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
     integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" 
     crossorigin="anonymous" referrerpolicy="no-referrer" />
     <link rel="stylesheet" href="css/stylep.css">
     <link href="img/icon.png" rel="icon">

    <title>Inicio de sesion</title>
   

</head>
<body class="bodyInicio">
    <form class="fromInicio" action="controller/controlador-registrar.php" method="POST">


        <div class="contenedorInicio">
            <img class="imgLogoInicio" src="img/utsLogos/UTSescudo.jpg" alt="Escudo de la UTS">
            <h1 class="tituloInicio">¡BIENVENIDO AL PORTAL ACADEMICO!</h1>
          </div>
        <br><br>

        <?php if (isset($_GET['error'])) { ?>
                        <div class="alert alert-success">
                            Usuario Registrado.
                        </div>
                    <?php } ?>

         <label class="labelInicio" for="">Usuario</label>  
         <input class="" type="text" name="usuario" id="Usuario" placholder="Nombre de Usuario"  required> 
         <label class="labelInicio" for="">Clave</label>  
         <input class="" type="text" name="clave" id="Clave" placholder="Clave"  required> 
         <label class="labelInicio" for="">Nombre</label>
         <input class="" type="text" name="nombre_completo" id="nombre_completo" placeholder=""  required>
         <hr>
         <button type="submit" name="registrar"  id="boton" value="Registrar" >Registrar</button>
         <p><a href="inicioSesion.php">¿Ya tengo cuenta? </a></p>

    </form>
</body>
</html>


