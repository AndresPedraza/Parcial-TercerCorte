<?php
// Conexión a la base de datos
$conexion = new mysqli('localhost', 'root', '', 'iniciodesesiondb');

// Verificar si la conexión fue exitosa
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Realizar la consulta para obtener las noticias
$sql = "SELECT * FROM noticias ORDER BY id DESC";
$resultado = $conexion->query($sql);

// Verificar si la consulta fue exitosa
if (!$resultado) {
    die("Error en la consulta: " . $conexion->error);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Noticias</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <link href="img/icon.png" rel="icon">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Rubik&display=swap" rel="stylesheet"> 

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="css/stylep.css">

</head>

<body>
    <div class="container-fluid bg-dark py-3 px-lg-5 d-none d-lg-block">
        <div class="row">
            <div class="col-md-6 text-center text-lg-left mb-2 mb-lg-0">
                <div class="d-inline-flex align-items-center">
                    <a class="text-body pr-3" href=""><i class="fa fa-phone-alt mr-2"></i>+57 313 3333358</a>
                    <span class="text-body">|</span>
                    <a class="text-body px-3" href=""><i class="fa fa-envelope mr-2"></i>infouts@gmail.com</a>
                </div>
            </div>
            <div class="col-md-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center">
                    <a class="text-body px-3" href="https://www.facebook.com/UnidadesTecnologicasdeSantanderUTS/?epa=SEARCH_BOX">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                   
                    <a class="text-body px-3" href="https://www.instagram.com/unidades_uts/?hl=els-la">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a class="text-body pl-3" href="https://www.youtube.com/channel/UC-rIi4OnN0R10Wp-cPiLcpQ">
                        <i class="fab fa-youtube"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>





    <div class="container-fluid position-relative nav-bar p-0">
        <div class="position-relative px-lg-5" style="z-index: 9;">
            <nav id="nav-Noticias"class="navbar navbar-expand-lg bg-secondary navbar-dark py-3 py-lg-0 pl-3 pl-lg-5">
                <a href="" class="navbar-brand">
                    <h1 id="texto-banner"  class="text-uppercase text-primary mb-1">NOTICIAS UTS</h1>
                </a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
                    <div class="navbar-nav ml-auto py-0">
                        <a id="texto-banner1" href="noticias.html" class="nav-item nav-link active">NOTICIAS</a>
                        <a id="texto-banner1" href="carreras.html" class="nav-item nav-link">CARRERAS</a>
                        <a id="texto-banner1" href="atencionalcliente.html" class="nav-item nav-link">ATENCION AL CIUDADANO</a>
                        <a id="texto-banner1" href="historia.html" class="nav-item nav-link">HISTORIA</a>
                        </div>
                        <a id="texto-banner1" href="contacto.html" class="nav-item nav-link">INFORMACION GENERAL</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
  

    
    <div class="container-fluid p-0" style="margin-bottom: 90px;">
        <div id="header-carousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="w-100" src="img/uts-Noticias/Noticia1.jpg" alt="Image">
                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 900px;">
                            <h1 class="display-1 text-white mb-md-4">"ADMISIONES"</h1>
                            
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="img/uts-Noticias/Noticia2.jpg" alt="Image">
                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 900px;">
                            <h1 class="display-1 text-white mb-md-4">"INVESTIGACIONES"</h1>
                        </div>
                    </div>
                </div>
            </div>
            <a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
                <div class="btn btn-dark" style="width: 45px; height: 45px;">
                    <span class="carousel-control-prev-icon mb-n2"></span>
                </div>
            </a>
            <a class="carousel-control-next" href="#header-carousel" data-slide="next">
                <div class="btn btn-dark" style="width: 45px; height: 45px;">
                    <span class="carousel-control-next-icon mb-n2"></span>
                </div>
            </a>
        </div>
    </div>


    <h1 class="tituloVideo">¡Bienvenidos a las Unidades Tecnologícas de Santander!</h1>
<br>
    <div class="video-container">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/pVwXs1aou_Y?si=4DYmM6QUnHkVWrIe" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

    </div>
  

  




    <div class="container-fluid py-5">
    <div class="container pt-5 pb-3">
        <h1 id="title-Noticias" class="display-4 text-uppercase text-center mb-5">Noticias UTS</h1>
        <div class="row">
            <?php
            // Verificar si hay noticias
            if ($resultado->num_rows > 0) {
                // Mostrar las noticias
                while ($row = $resultado->fetch_assoc()) {
                    echo '<div class="col-lg-4 col-md-6 mb-2">';
                    echo '<div class="rent-item mb-4">';
                    echo '<img class="img-fluid mb-4" src="' . $row['imagen'] . '" alt="Imagen de noticia">';
                    echo '<h4 class="text-uppercase mb-4">' . $row['descripcion'] . '</h4>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                // Si no hay noticias, mostrar un mensaje
                echo '<p>No hay noticias disponibles.</p>';
            }
            ?>
        </div>
    </div>
</div>

























<h4 class="title-Noticias2">Links de interés</h4>



    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="owl-carousel vendor-carousel">
                <div class="bg-light p-4">
                    <img src="img/Enlaces-Interes/icon-agenda.jpg" alt="">
                </div>
                <div class="bg-light p-4">
                    <img src="img/Enlaces-Interes/icon-bandera.jpg" alt="">
                </div>
                <div class="bg-light p-4">
                    <img src="img/Enlaces-Interes/icon-revista.jpg" alt="">
                </div>
                <div class="bg-light p-4">
                    <img src="img/Enlaces-Interes/icon-turadio.jpg" alt="">
                </div>
                <div class="bg-light p-4">
                    <img src="img/Enlaces-Interes/iconos-5.jpg" alt="">
                </div>
                <div class="bg-light p-4">
                    <img src="img/Enlaces-Interes/BOTON-SOPORTE-CASA1-1.png" alt="">
                </div>
               
            </div>
        </div>
    </div>

   
    <div class="container-fluid bg-light py-4 px-sm-3 px-md-5">
        <p class="mb-2 text-center text-body">&copy; <a id="CopyR" href="#">UnidadUTS</a> Todos los derechos reservados.</p>
        <p class="m-0 text-center text-body">Designed by Jesus Pimiento & Andres Pedraza</p>
    </div>


    
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top" id="icono-volver"><i class="fa fa-angle-double-up"  ></i></a>






    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <script src="js/main.js"></script>
</body>


</html>