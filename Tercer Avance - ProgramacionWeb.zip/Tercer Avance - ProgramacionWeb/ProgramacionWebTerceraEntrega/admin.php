
<?php
   $id = isset($_GET['id']) ? $_GET['id'] : null;
   $nombre = isset($_GET['nombre']) ? $_GET['nombre'] : null;
   $clave = isset($_GET['clave']) ? $_GET['clave'] : null;
   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-eqiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" 
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="frame/style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
     integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" 
     crossorigin="anonymous" referrerpolicy="no-referrer" />
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" 
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="frame/style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
     integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" 
     crossorigin="anonymous" referrerpolicy="no-referrer" />
     <link href="img/icon.png" rel="icon">
     <link rel="stylesheet" href="css/stylep.css">


    <title>Inicio de sesion</title>
   

</head>
<body class="bodyInicio">
<form class="fromInicio" action="controller/controlador-admin.php" method="POST">

   
<div class="contenedorInicio">
    <img class="imgLogoInicio" src="img/utsLogos/UTSescudo.jpg" alt="Escudo de la UTS">
    <h1 class="tituloInicio">¡ADMINISTRACION!</h1>
  </div>
    <br><br>

    <?php if (isset($_GET['errorr'])) { ?>
                        <div class="alert alert-danger">
                            Usuario No Existe
                        </div>
                    <?php } ?>


                    <?php if (isset($_GET['Eliminado'])) { ?>
                        <div class="alert alert-success">
                            Usuario Eliminado
                        </div>
                    <?php } ?>


                    <?php if (isset($_GET['NOEliminadoerrorr'])) { ?>
                        <div class="alert alert-danger">
                            Usuario No Eliminado / No existe
                        </div>
                    <?php } ?>





                    <?php if (isset($_GET['Actualizado'])) { ?>
                        <div class="alert alert-success">
                            Usuario se ha Actualizado
                        </div>
                    <?php } ?>


                    <?php if (isset($_GET['NOActualizoerrorr'])) { ?>
                        <div class="alert alert-danger">
                            Usuario No Actualizado / No existe
                        </div>
                    <?php } ?>


    <label class="labelInicio" for="">ID</label>  
    <input class="inputInicio" type="text" name="id" id="Id"  value="<?php echo $id  ?>" > 
    <label class="labelInicio" for="">Nombre</label>  
    <input class="inputInicio" type="text" name="nombre" id="Clave"  value="<?php echo $nombre  ?>"> 
    <label class="labelInicio" for="">Clave</label>  
    <input class="inputInicio" type="text" name="clave" id="Nombre"  value="<?php echo $clave  ?>"> 
    <hr>
    <button type="submit" name="btnConsultar"  id="boton" value="boton" >Consultar</button>
    <button type="submit" name="btnActualizar"  id="boton" value="boton" >Actualizar</button>
    <button type="submit" name="btnEliminar"  id="boton" value="boton" >Eliminar</button>
    <a href="editNoticias.php"  id="boton">Registro de Noticias</a>

</form>











</body>
</html>


