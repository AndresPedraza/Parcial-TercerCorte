<?php

include('../motordb/conexionRegistrp.php');

if(isset($_POST['registrar'])){

if (strlen($_POST['usuario']) && strlen($_POST['clave'])  ) {
    $usuario = trim($_POST['usuario']);
    $clave = trim($_POST['clave']);
    $nombre_completo = trim($_POST['nombre_completo']);
    $consulta = "INSERT INTO `usuarios`(`id`, `usuario`, `clave`, `Nombre_completo`) VALUES ('','$usuario','$clave','$nombre_completo')";
    $resultado = mysqli_query($conexion,$consulta);
    if ($resultado) {

   
        header("Location: ../crearCuenta.php?error=true");


            
       
    }else {
     
        header("Location: ../crearCuenta.php?error=true");
      
        }
    }else{
      
        header("Location: ../crearCuenta.php?error=true");
      
    
    }
}

?>





