<?php




session_start();
include('../motordb/conexion.php');

if(isset($_POST["Usuario"]) && isset($_POST["Clave"])){
function validate ($data){
    

$data = trim($data);
$data = stripslashes($data);
$data = htmlspecialchars($data);
return $data;

}

$Usuario = validate ($_POST["Usuario"]);
$Clave = validate ($_POST["Clave"]);     

if (empty($Usuario)) {
    header("Location: ../admin.php?error= El usuario es requerido");
} elseif (empty($Clave)) {
    header("Location: ../admin.php?error= La clave es requerido");
    exit();
}else{


    $Sql = "SELECT * FROM admins WHERE usuario = '$Usuario' AND clave = '$Clave' ";
    $result = mysqli_query($conexion, $Sql);
    
    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if($row['usuario'] === $Usuario && $row['clave'] === $Clave){
            $_SESSION['usuario'] = $row['usuario'];
            $_SESSION['Id'] = $row['Id'];
            header("Location: ../admin.php");
            exit();
        } else{

            header("Location: ../inicioadmin.php?error=true");
            exit();        
        }
    }else{
            header("Location: ../inicioadmin.php?error=true");
            exit(); 
    }

}

}else{
    header("Location: ../inicioAdmin.php");
    exit();
}

?>