
<?php
// Conexión a la base de datos
$conexion = new mysqli('localhost', 'root', '', 'iniciodesesiondb');
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Agregar noticia
if (isset($_POST['agregar'])) {
    $descripcion = $_POST['descripcion'];

    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] == 0) {

        $target_dir = "img/portada-Noticias/";


        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true); 
            
        }

        $target_file = $target_dir . basename($_FILES["imagen"]["name"]);

        if (move_uploaded_file($_FILES["imagen"]["tmp_name"], $target_file)) {

            $stmt = $conexion->prepare("INSERT INTO noticias (descripcion, imagen) VALUES (?, ?)");
            $stmt->bind_param("ss", $descripcion, $target_file);
            if ($stmt->execute()) {
                echo "Noticia agregada correctamente.";
            } else {
                echo "Error al agregar noticia: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Error al cargar la imagen.";
        }
    } else {
        echo "Error al cargar la imagen. Código de error: " . $_FILES['imagen']['error'];
    }
}

// Eliminar noticia
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];

    $sql = "SELECT imagen FROM noticias WHERE id = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $row = $resultado->fetch_assoc();
    $imagen_a_eliminar = $row['imagen'];


    if (file_exists($imagen_a_eliminar)) {
        if (unlink($imagen_a_eliminar)) {
            echo "Imagen eliminada correctamente.";
        } else {
            echo "Error al eliminar la imagen.";
        }
    }



    $sql = "DELETE FROM noticias WHERE id = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        echo "Noticia eliminada correctamente.";
        
    } else {
        echo "Error al eliminar noticia: " . $stmt->error;
    }
    $stmt->close();
}


if (isset($_POST['modificar'])) {
    $id = $_POST['id'];
    $descripcion = $_POST['descripcion'];


    $sql = "UPDATE noticias SET descripcion = ? WHERE id = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("si", $descripcion, $id);
    if ($stmt->execute()) {
        echo "Noticia modificada correctamente.";
    } else {
        echo "Error al modificar noticia: " . $stmt->error;
    }
    $stmt->close();
}
?>
