<?php

include('../motordb/conexionAdmin.php');

$miconexion = new ConexionMYSQL();
$miconexion->CrearConexion();

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$clave = $_POST['clave'];



///CONSULTAR////



if (isset($_POST['btnConsultar'])) { 
    $id = $_POST['id']; 

    $sql = "SELECT * FROM usuarios WHERE id = " . $id;  
    $result = $miconexion->EjecutarSQL($sql);  
    if ($result) {
        $row = $miconexion->ObtenerFilas($result);  
        if ($row) {
         
            header("Location: ../admin.php?id=" . $row[0] . "&nombre=" . $row[1] . "&clave=" . $row[2]);
            exit(); 
        } else {
           
            header("Location: ../admin.php?errorr=true");
            exit();  
        }
    } else {
     
        header("Location: ../admin.php?errorr=true");
        exit();
    }
}


///ELIMINAR////
if (isset($_POST['btnEliminar'])) {
    $id = $_POST['id'];

    $sql = "DELETE FROM usuarios WHERE id = " . $id;
    $result = $miconexion->EjecutarSQL($sql);

    if ($result) {
        $numfilas = $miconexion->ObtenerColumnasAfectadas();
        if ($numfilas > 0) {  
            header("Location: ../admin.php?Eliminado=true");
            exit();
        } else {
            header("Location: ../admin.php?NOEliminadoerrorr=true");
            exit();
        }
    } else {
        header("Location: ../admin.php?NOEliminadoerrorr=true");
        exit();
    }
}

    



///ACTUALIZAR///


if($_POST['btnActualizar']){
$sql = "UPDATE usuarios SET usuario='".$nombre."', clave='".$clave."' WHERE id=".$id;
    $result = $miconexion->EjecutarSQL($sql);  
    if($result){
        if($result > 0){


            echo "<br> Se ha ACTUALIZADO exitosamente. <br>";
            header("Location: ../admin.php?Actualizado=true");
            exit();


        } else {

            header("Location: ../admin.php?NOActualizoerrorr=true");
            exit();
        }
    } else {
        header("Location: ../admin.php?NOActualizoerrorr=true");
        exit();
    }
}

?>